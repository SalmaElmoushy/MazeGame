﻿import sys
import time

class MazeGame:
    def __init__(self):
        self.maze = [[5,1,1,1,0,0,1,1,1,0],
                     [1,0,0,1,1,1,1,0,1,1],
                     [0,1,1,0,0,0,1,0,0,0],
                     [0,0,0,0,0,0,1,0,0,1],
                     [1,0,1,0,0,1,1,0,1,1],
                     [0,0,1,0,0,1,0,0,0,1],
                     [0,1,0,1,1,1,1,0,0,0],
                     [1,1,1,0,0,1,0,0,0,0],
                     [1,1,0,1,0,1,0,1,1,0],
                     [0,0,0,0,0,1,1,1,1,9]]
        self.row = 0
        self.col = 0
        self.lives = 3
        self.again = 1

    def displayMaze(self):
        for i in range(len(self.maze)):
            for j in range(len(self.maze[0])):
                if self.maze[i][j] == 5:
                    print("x", end="")
                elif self.maze[i][j] == 1:
                    print(" ", end="")
                elif self.maze[i][j] == 0:
                    print("-", end="")
                elif self.maze[i][j] == 9:
                    print("*", end="")
            print()

    def playGame(self):
        flag = 0
        while self.maze[9][9] != 5:
            d = input("Enter direction: ")
            if d == 'w':
                self.moveUp(self.row, self.col)
            elif d == 's':
                self.moveDown(self.row, self.col)
            elif d == 'a':
                self.moveLeft(self.row, self.col)
            elif d == 'd':
                self.moveRight(self.row, self.col)
            elif d == 'x':
                print("End of the program")
                flag = 1
                break
            else:
                print("Wrong input")
            self.displayMaze()
        if flag == 0:
            print("Congratulations! You won.")
    
    def moveUp(self, r, c):
        if r == 0 or self.maze[r-1][c] == 0:
            print("Invalid command! Try again.")
            self.lives -= 1
            print("Your left lives: " + str(self.lives))
        else:
            self.maze[r][c] = 1
            self.maze[r-1][c] = 5
            self.row = r-1
        if self.lives == 0:
            print("Sorry, you lost all your lives")
            self.again = input("Do you want to exit? answer(0): ")
            if(self.again == "0"):
                exit()
            else: 
                self.lives = 3

    def moveDown(self, r, c):
        if r == 9 or self.maze[r+1][c] == 0:
            print("Invalid command! Try again.")
            self.lives -= 1
            print("Your left lives: " + str(self.lives))
        else:
            self.maze[r][c] = 1
            self.maze[r+1][c] = 5
            self.row = r+1
        if self.lives == 0:
            print("Sorry, you lost all your lives")
            self.again = input("Do you want to play again? answer(1/0): ")
            if(self.again == "0"):
                exit()
            else: 
                self.lives = 3

    def moveLeft(self, r, c):
        if c == 0 or self.maze[r][c-1] == 0:
            print("Invalid command! Try again.")
            self.lives -= 1
            print("Your left lives: " + str(self.lives))
        else:
            self.maze[r][c] = 1
            self.maze[r][c-1] = 5
            self.col = c-1
        if self.lives == 0:
            print("Sorry, you lost all your lives")
            self.again = input("Do you want to play again? answer(1/0): ")
            if(self.again == "0"):
                exit()
            else: 
                self.lives = 3

    def moveRight(self, r, c):
        if c == 9 or self.maze[r][c+1] == 0:
            print("Invalid command! Try again.")
            self.lives -= 1
            print("Your left lives: " + str(self.lives))
        else:
            self.maze[r][c] = 1
            self.maze[r][c+1] = 5
            self.col = c+1
        if self.lives == 0:
            print("Sorry, you lost all your lives")
            self.again = input("Do you want to play again? answer(1/0): ")
            if(self.again == "0"):
                exit()
            else: 
                self.lives = 3

if __name__ == '__main__':
    name = input("Enter your name: ")
    age = int(input("Enter your age: "))
    
    if age < 10:
        print("Sorry, you are young for the game")
        sys.exit(1)
    else:
        print("Hi", name, "Let's start! The rules are simple:")
        time.sleep(2)
        print("w (move up), s (move down), d (move right), and a (move left)")
        time.sleep(2)
        print("Note: you have only 3 lives")
        time.sleep(2)

ob = MazeGame()
ob.displayMaze()
ob.playGame()



